def welcome():
    print("\t","/// Welcome to GIR \\\\\\")
    print("\t","\\\\\\'Guess It Right'///")       
    print()
    print()


def rule():
    print("""GAME RULES:
        (A) Three levels in this game:
            1. Easy Mode:-Player has three chances to guess correct number.
            2. Medium:-Two chances
            3. Hard:-SINGLE CHANCE
        (B) Guess numbers correctly and score higher :)
        """)